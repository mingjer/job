-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: 58.59.11.86    Database: acct
-- ------------------------------------------------------
-- Server version	5.7.20-enterprise-commercial-advanced-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `product_info`
--
use acct;
LOCK TABLES `product_info` WRITE;
/*!40000 ALTER TABLE `product_info` DISABLE KEYS */;
INSERT INTO `product_info` VALUES (1,'1001','subjectcode','2003.01','','1'),(2,'1001','balancedirection','C','','1'),(3,'1001','rateid','1','','1'),(4,'1001','interestperiod','1','','1'),(5,'1001','interestdate','20140101','','1'),(6,'1001','interestinacct','12','','1'),(7,'1001','overdrawflag','1','','1'),(8,'1001','overdrawacct','0','','1'),(9,'1001','overdrawinacct2','1','','1'),(10,'1001','overdrawinacct','1','','1'),(11,'1001','overdrawinteracct','1','','1'),(12,'1001','interestscalflag','1','','1'),(13,'1001','dayscalflag','1','','1'),(14,'1001','pointscalflag','2','','1'),(15,'1001','ininterestsflag','2','','1'),(16,'1001','allowoverdrawflag','1','','1'),(17,'1001','dueflag','1','','1'),(18,'1001','depositid','1','','1'),(19,'1001','remark','1','','1'),(20,'9001','subjectcode','3021','','3'),(21,'9001','balancedirection','D','','3'),(22,'9001','rateid','1','','3'),(23,'9001','interestperiod','1','','3'),(24,'9001','interestdate','20140101','','3'),(25,'9001','interestinacct','12','','3'),(26,'9001','overdrawflag','1','','3'),(27,'9001','overdrawacct','1','','3'),(28,'9001','overdrawinacct2','1','','3'),(29,'9001','overdrawinacct','1','','3'),(30,'9001','overdrawinteracct','1','','3'),(31,'9001','interestscalflag','0','','3'),(32,'9001','dayscalflag','1','','3'),(33,'9001','pointscalflag','1','','3'),(34,'9001','ininterestsflag','2','','3'),(35,'9001','allowoverdrawflag','1','','3'),(36,'9001','dueflag','1','','3'),(37,'9001','depositid','1','','3'),(38,'9001','remark','1','','3'),(39,'1003','subjectcode','160.02','','1'),(40,'1003','balancedirection','C','','1'),(41,'9003','subjectcode','160.01','','3'),(42,'9003','balancedirection','C','','3'),(43,'1003','subjectcode','160.02','','2'),(44,'1003','balancedirection','C','','2'),(45,'1001','subjectcode','2003.01','','2'),(46,'1001','balancedirection','C','','2'),(47,'1001','rateid','1','','2'),(48,'1001','interestperiod','1','','2'),(49,'1001','interestdate','20140101','','2'),(50,'1001','interestinacct','12','','2'),(51,'1001','overdrawflag','1','','2'),(52,'1001','overdrawacct','0','','2'),(53,'1001','overdrawinacct2','1','','2'),(54,'1001','overdrawinacct','1','','2'),(55,'1001','overdrawinteracct','1','','2'),(56,'1001','interestscalflag','1','','2'),(57,'1001','dayscalflag','1','','2'),(58,'1001','pointscalflag','2','','2'),(59,'1001','ininterestsflag','2','','2'),(60,'1001','allowoverdrawflag','1','','2'),(61,'1001','dueflag','1','','2'),(62,'1001','depositid','1','','2'),(63,'1001','remark','1','','2'),(64,'9001','curr','CNY','','3'),(65,'9001','subacctproname','内部户账户','','3'),(66,'9003','curr','XX1','','3'),(67,'9003','subacctproname','内部户积分子账户','','3'),(68,'1001','curr','CNY','','1'),(69,'1001','subacctproname','人民币子账户','','1'),(70,'1001','curr','CNY','','2'),(71,'1001','subacctproname','人民币子账户','','2'),(72,'1003','curr','XX1','','1'),(73,'1003','subacctproname','积分子账户','','1'),(74,'1003','curr','XX1','','2'),(75,'1003','subacctproname','积分子账户','','2'),(76,'1005','subjectcode','2003.01','','1'),(77,'1005','balancedirection','C','','1'),(78,'1005','rateid','1','','1'),(79,'1005','interestperiod','1','','1'),(80,'1005','interestdate','20140101','','1'),(81,'1005','interestinacct','12','','1'),(82,'1005','overdrawflag','1','','1'),(83,'1005','overdrawacct','0','','1'),(84,'1005','overdrawinacct2','1','','1'),(85,'1005','overdrawinacct','1','','1'),(86,'1005','overdrawinteracct','1','','1'),(87,'1005','interestscalflag','5','','1'),(88,'1005','dayscalflag','1','','1'),(89,'1005','pointscalflag','2','','1'),(90,'1005','ininterestsflag','2','','1'),(91,'1005','allowoverdrawflag','1','','1'),(92,'1005','dueflag','1','','1'),(93,'1005','depositid','1','','1'),(94,'1005','remark','1','','1'),(95,'1005','curr','CNY','','1'),(96,'1005','subacctproname','智能存款子账户','','1'),(97,'1005','subjectcode','2003.01','','2'),(98,'1005','balancedirection','C','','2'),(99,'1005','rateid','1','','2'),(100,'1005','interestperiod','1','','2'),(101,'1005','interestdate','20140101','','2'),(102,'1005','interestinacct','12','','2'),(103,'1005','overdrawflag','1','','2'),(104,'1005','overdrawacct','0','','2'),(105,'1005','overdrawinacct2','1','','2'),(106,'1005','overdrawinacct','1','','2'),(107,'1005','overdrawinteracct','1','','2'),(108,'1005','interestscalflag','5','','2'),(109,'1005','dayscalflag','1','','2'),(110,'1005','pointscalflag','2','','2'),(111,'1005','ininterestsflag','2','','2'),(112,'1005','allowoverdrawflag','1','','2'),(113,'1005','dueflag','1','','2'),(114,'1005','depositid','1','','2'),(115,'1005','remark','1','','2'),(116,'1005','curr','CNY','','2'),(117,'1005','subacctproname','智能存款子账户','','2'),(118,'1001','normalfloatingrate','0','','1'),(119,'1001','normalfloatingrate','0','','2'),(120,'1005','normalfloatingrate','0','','1'),(121,'1005','normalfloatingrate','0','','2');
/*!40000 ALTER TABLE `product_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-22 14:30:14
