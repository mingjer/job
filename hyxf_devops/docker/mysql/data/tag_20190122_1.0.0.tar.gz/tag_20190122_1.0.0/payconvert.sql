-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: 58.59.11.86    Database: payconvert
-- ------------------------------------------------------
-- Server version	5.7.20-enterprise-commercial-advanced-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
use payconvert
--
-- Dumping data for table `convert_pay_channel_relation`
--

LOCK TABLES `convert_pay_channel_relation` WRITE;
/*!40000 ALTER TABLE `convert_pay_channel_relation` DISABLE KEYS */;
INSERT INTO `convert_pay_channel_relation` VALUES ('000','0','未知',NULL,'UNKNOW','x','未知'),('000','1','宝付代扣','3301040160003850552','BAOFOO','312','宝付支付'),('000','10','平安代扣','19014528472950','PINGAN','406','平安银行'),('000','12','农业银行直连代扣','19033301040026265','NONGYE','407','农业银行'),('000','13','邮储银行直连代扣','933002010029968889','YOUCHU','c015','邮政储蓄'),('000','14','建设银行直连代扣','33050161883500001041','CCB','c011','建设银行'),('000','15','兴业直连','321190100100267347','CIBHSF','c010','兴业直连'),('000','16','浦发直连','95230153900000010','SPD','c017','浦发直连'),('000','17','民生直连','692602696','CMBC','c016','民生直连'),('000','2','宝付协议支付','3301040160003850552','BAOFOO','312','宝付支付'),('000','3','易宝代扣','3301040160003850552','YEEBAO','304','易宝支付'),('000','30','杭州银行代付','3301040160003850552','HANG_YIN','c007','杭州银行'),('000','31','宝付代付','3301040160003850552','BAOFOO','312','宝付支付'),('000','32','平安代付','19014528472950','PINGAN_DF','c110','平安代付'),('000','4','易宝协议代扣','3301040160003850552','YEEBAO','304','易宝支付'),('000','5','杭州银行代扣','3301040160003850552','HANG_YIN','c007','杭州银行'),('000','6','工行银行代扣','4000029919200604054','ICBC','401','工行'),('000','7','京东协议代扣','3301040160003850552','JDPAY','321','京东支付'),('000','ABC','农业银行直连通道','19033301040026265','NONGYE','407','农业银行'),('000','BaoFoo','宝付通道','3301040160003850552','BAOFOO','312','宝付支付'),('000','BFB','百付宝支付','506000000000132','BAIFUBAO','c014','百付宝'),('000','CCB','建设银行直连代扣','33050161883500001041','CCB','c011','建设银行'),('000','CIBHSF','兴业直连','321190100100267347','CIBHSF','c010','兴业直连'),('000','CMBC','民生直连','692602696','CMBC','c016','民生直连'),('000','HZBank','杭银通道','3301040160003850552','HANG_YIN','c007','杭州银行'),('000','ICBC','杭银工商银行通道','4000029919200604054','ICBC','401','工行'),('000','JD','杭银京东通道','3301040160003850552','JDPAY','321','京东支付'),('000','JF','捷付通道','33050161883500001041','JIEFU','c013','捷付'),('000','offline','线下打款','','OFFLINE','d001','线下打款'),('000','PAB','杭银平安银行通道','19014528472950','PINGAN','406','平安银行'),('000','PSBC','邮储银行直连代扣','933002010029968889','YOUCHU','c015','邮政储蓄'),('000','SPD','浦发直连','95230153900000010','SPD','c017','浦发直连'),('000','TongLian','通联通道','3301040160003850552','TONGLIAN','002','通联'),('000','TOU_TIAO','连连通道','3301040160003850552','lianlian','c109','连连'),('000','WeiXin','微信支付通道','95230078801900000162','WXPAY','302','微信'),('000','YeeBao','易宝通道','3301040160003850552','YEEBAO','304','易宝支付'),('000','ZhongJin','中金通道','9550880210716900137','CPCNPAY','305','中金支付');
/*!40000 ALTER TABLE `convert_pay_channel_relation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-22 14:30:14
